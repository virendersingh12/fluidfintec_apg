
let ROOT_PATH = __dirname;


const stripeCredentials = {
    publishKey: "pk_live_51MVwuvCFv9B2FlUPKeYcsDWqw576B8bFgDDItQAbt9pAnkTijYkI5fuWiWIm4fI2J1PoPsnpo9B9YJ3KbWUjhJKs00vkVd1lOT",
    secretKey: "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"
}
// const stripeCredentials = {
//     publishKey: "pk_test_51MVwuvCFv9B2FlUPoqp74VeJ6b060IKcpWxEWfMS5rIMG7OvIwGARaqWg98QJyd5OxrBgEepOadfnhcu1Q6UaLwn00xLkMCPCL",
//     secretKey: "sk_test_51MVwuvCFv9B2FlUPGMnC6MYIUyFBYRY1LrvQ0f2ygfV2TeJVf1ZgH5S8F4LPEfRWBEnaPSA5vYLUI9rCDX375GCh00JTL3uwe9"
// }






module.exports = {
    // BASE_URL: process.env.BASE_URL,
    // API_VERSION: process.env.API_VERSION,
    // SERVER: process.env.SERVER,
    JWT_SECRET: 'RealidodDKJr&gvCu30aGU8Bji816d98ced4edfd55f',
    JWT_REFRESH_TOKEN_SECRET: 'Realido08VJ3f5bddDKJ036DTNJDKssdsn6650bI77u',
    // JWT_TOKEN_LIFE: process.env.JWT_TOKEN_LIFE,
    // JWT_REFRESH_TOKEN_LIFE: process.env.JWT_REFRESH_TOKEN_LIFE,
    // X_API_KEY: process.env.X_API_KEY,
    PWD_SECRET: 'Real21XC@Z%7yh@@$^&&^%',
    ROOT_PATH,
    stripeCredentials,
};